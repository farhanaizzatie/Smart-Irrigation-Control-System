package com.example.sics3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.example.sics3.SensorDashboard;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ActuatorDashboard extends AppCompatActivity {

    Button onP,offP, onL, offL;
    TextView moist;
    String statusM, statusT, statusH, statusL;
    private FirebaseUser mFirebaseuser;
    private String mUserID;
    private FirebaseAuth mAuth;

    FirebaseDatabase myDatabase=FirebaseDatabase.getInstance();
    DatabaseReference ref ;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actuator);

        onP = (Button) findViewById(R.id.pump_on);
        offP = (Button) findViewById(R.id.pump_off);
        onL = (Button) findViewById(R.id.led_on);
        offL = (Button) findViewById(R.id.led_off);
        moist = (TextView) findViewById(R.id.textViewStatus);

        ref = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        mFirebaseuser=mAuth.getCurrentUser();
        mUserID=mFirebaseuser.getUid();

        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                statusM = dataSnapshot.child("moisture").getValue().toString();
                moist.setText("Moisture level: " + statusM);


                onP.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("PUMP_STATUS");
                        myRef.setValue(1);
                        Toast.makeText(ActuatorDashboard.this, "PUMP ON.",
                                Toast.LENGTH_SHORT).show();
                    }
                });

                offP.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("PUMP_STATUS");
                        myRef.setValue(0);
                        Toast.makeText(ActuatorDashboard.this, "PUMP OFF.",
                                Toast.LENGTH_SHORT).show();
                    }
                });

                onL.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("LED_STATUS");
                        myRef.setValue(1);
                        Toast.makeText(ActuatorDashboard.this, "LED ON.",
                                Toast.LENGTH_SHORT).show();
                    }
                });

                offL.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("LED_STATUS");
                        myRef.setValue(0);
                        Toast.makeText(ActuatorDashboard.this, "LED OFF.",
                                Toast.LENGTH_SHORT).show();
                    }
                });

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

    }
}
