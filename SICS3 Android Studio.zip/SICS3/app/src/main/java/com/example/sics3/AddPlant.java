package com.example.sics3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AddPlant extends AppCompatActivity {


    private EditText plantName, soil_type,crop_type;
    private Button add_plant ;
    DatabaseReference mDatabase;
    private FirebaseAuth mAuth;
    private FirebaseUser mFirebaseuser;
    private String mUserID;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_plant);


        plantName = findViewById(R.id.editTextName);
        soil_type = findViewById(R.id.editSoilType);
        crop_type=findViewById(R.id.crop_type);
        add_plant = findViewById(R.id.btnSave);

        mAuth = FirebaseAuth.getInstance();
        mFirebaseuser=mAuth.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mUserID=mFirebaseuser.getUid();


        add_plant.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                //Getting values to store
                String name = plantName.getText().toString().trim();
                String soil = soil_type.getText().toString().trim();
                String crop = crop_type.getText().toString().trim();

                String plant_id = mDatabase.push().getKey();

                //Creating plant object
                PlantDetails plant = new PlantDetails();

                //Adding values
                plant.setPlant_name(name);
                plant.setSoil_type(soil);
                plant.setCrop_type(crop);
                plant.setPlant_id(plant_id);

                if(!name.isEmpty() && !soil.isEmpty() && !crop.isEmpty() ) {

                    //Storing values to firebase
                    mDatabase.child("Users").child(mUserID).child("plant").push().setValue(plant);
                   // mDatabase.child("HistoryTable").child(mUserID).push().setValue(plant);
                    Toast.makeText(
                            AddPlant.this, "Plant profile created.",
                            Toast.LENGTH_SHORT).show();
                    plantName.setText("");
                    soil_type.setText("");
                    crop_type.setText("");

                    }else{Toast.makeText(
                        AddPlant.this, "Fail to add plant profile.",
                        Toast.LENGTH_SHORT).show();}
                }


        });

    }


    public void view_plant_list(View v){
        Intent i = new Intent(this, ViewPlant.class);
        startActivity(i);
    }
}


