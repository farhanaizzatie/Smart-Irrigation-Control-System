package com.example.sics3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class AdminDashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_dashboard);

   /*     FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();

        if (user != null && user.isEmailVerified()){
            Intent ints = new Intent(this, MainActivity.class);
            startActivity(ints);
        }
*/
    }

    SessionManager sessionManager;

    public void activity_user(View view) {
        Intent ints = new Intent(this, ViewUser.class);
        startActivity(ints);
    }

    public void activity_report(View v) {
        Intent ints = new Intent(this, Report.class);
        startActivity(ints);

    }

    public void logout(View v) {
        FirebaseAuth.getInstance().signOut();

        sessionManager.setLogin(false);
        sessionManager.setUserName("");

        Intent ints = new Intent(this, SigninActivity.class);
        startActivity(ints);

    }
}
