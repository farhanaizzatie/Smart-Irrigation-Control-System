package com.example.sics3;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

   /*     FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();

        if (user != null && user.isEmailVerified()){
            Intent ints = new Intent(this, MainActivity.class);
            startActivity(ints);
        }
*/
    }


    public void activity_sensor(View view) {
        Intent ints = new Intent(this, SensorDashboard.class);
        startActivity(ints);
    }

    public void add_plant(View view) {
        Intent ints = new Intent(this, AddPlant.class);
        startActivity(ints);
    }
    public void activity_actuator(View view) {
        Intent ints = new Intent(this, ActuatorDashboard.class);
        startActivity(ints);
    }

    public void logout(View v) {
        FirebaseAuth.getInstance().signOut();

        //sessionManager.setLogin(false);
        sessionManager.setUserName("");

        Intent ints = new Intent(this, SigninActivity.class);
        startActivity(ints);

    }


}