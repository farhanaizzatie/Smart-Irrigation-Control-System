package com.example.sics3;

public class PlantDetails {


    String plant_id;
    String plant_name;
    String soil_type;
    String crop_type;


    public PlantDetails() {
    }

    public PlantDetails(String plant_id, String plant_name, String soil_type, String crop_type) {
        this.plant_id = plant_id;
        this.plant_name = plant_name;
        this.soil_type = soil_type;
        this.crop_type = crop_type;
    }

    public String getPlant_id() {
        return plant_id;
    }

    public void setPlant_id(String plant_id) {
        this.plant_id = plant_id;
    }
    public String getPlant_name() {
        return plant_name;
    }

    public void setPlant_name(String plant_name) {
        this.plant_name = plant_name;
    }

    public String getSoil_type() {
        return soil_type;
    }

    public void setSoil_type(String soil_type) {
        this.soil_type = soil_type;
    }

    public String getCrop_type() {
        return crop_type;
    }

    public void setCrop_type(String crop_type) {
        this.crop_type = crop_type;
    }
}
