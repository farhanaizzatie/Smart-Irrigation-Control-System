package com.example.sics3;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class PlantList extends ArrayAdapter<PlantDetails> {

    private Activity context;
    List<PlantDetails> plantList;

    public PlantList(Activity context, List<PlantDetails> plantList) {
        super(context, R.layout.layout_plant_list, plantList);
        this.context = context;
        this.plantList = plantList;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.layout_plant_list, null, true);

        TextView textViewName = (TextView) listViewItem.findViewById(R.id.textViewName);
        TextView textViewCrop = (TextView) listViewItem.findViewById(R.id.textViewCrop);
        TextView textViewSoil = (TextView) listViewItem.findViewById(R.id.textViewSoil);

        PlantDetails plantDetails = plantList.get(position);

        textViewName.setText(plantDetails.getPlant_name());
        textViewCrop.setText(plantDetails.getCrop_type());
        textViewSoil.setText(plantDetails.getSoil_type());

        return listViewItem;
    }
}
