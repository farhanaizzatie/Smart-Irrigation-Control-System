package com.example.sics3;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Report extends AppCompatActivity {

    TextView viewTitle,viewmMonth;
    Spinner monthSpinner;
    ListView listViewReport;
    List<SaveDataPojo> dataLists;

    DatabaseReference databaseUser;


  /*  SimpleDateFormat sdf=new SimpleDateFormat("hh:mm");
    SimpleDateFormat month=new SimpleDateFormat("MMM");
    SimpleDateFormat todayDate=new SimpleDateFormat("dd");
    SimpleDateFormat ctn = new SimpleDateFormat("hh:mm:ss");
    Date currentTime ;
    String monthNow;*/

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.report_design);

    /*    viewTitle    = findViewById(R.id.showTitle);
      //  monthSpinner = findViewById(R.id.spinner_monthD);

        listViewData  = (ListView) findViewById(R.id.listOfDataD);

       // currentTime      = Calendar.getInstance().getTime();
        //monthNow         = month.format(currentTime);

        dataLists = new ArrayList<SaveDataPojo>();

        database=FirebaseDatabase.getInstance();

      //  monthSpinner = findViewById(R.id.spinner_monthD);

        ArrayAdapter<String> mySpinnerAdapter = new ArrayAdapter<String>(Report.this, android.R.layout.simple_spinner_dropdown_item,
                getResources().getStringArray(R.array.month));
        mySpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        monthSpinner.setAdapter(mySpinnerAdapter);*/

        //dataListRef = FirebaseDatabase.getInstance().getReference("HistoryTable").child(isSelected);

        databaseUser = FirebaseDatabase.getInstance().getReference("Users");

        listViewReport = (ListView) findViewById(R.id.list_view_plant);

        dataLists = new ArrayList<>();

        listViewReport.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int i, long l) {
                SaveDataPojo report = dataLists.get(i);
                //showUpdateDeleteDialog(usrDetail.getUsr_id(), usrDetail.getUsr_name());
                return true;
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        databaseUser.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                //clearing the previous artist list
                dataLists.clear();

                //iterating through all the nodes
                for (DataSnapshot userSnapShot : dataSnapshot.getChildren()) {

                    //getting artist
                    SaveDataPojo usrDetail = userSnapShot.getValue(SaveDataPojo.class);

                    dataLists.add(usrDetail);
                }

                ReportDetail adapter = new ReportDetail(Report.this, dataLists);
                listViewReport.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

}
