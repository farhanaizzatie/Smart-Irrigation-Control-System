package com.example.sics3;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Date;
import java.util.List;

public class ReportDetail extends ArrayAdapter<SaveDataPojo> {

    private Activity context;
    private List<SaveDataPojo> dataList;

    public ReportDetail(Activity context, List<SaveDataPojo> dataList){
        super(context, R.layout.report_content, dataList);

        this.context = context;
        this.dataList = dataList;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View ListViewItem = inflater.inflate(R.layout.report_content, null,true);

        TextView viewName = ListViewItem.findViewById(R.id.textNameValue);
        TextView viewPlant = ListViewItem.findViewById(R.id.textPlantValue);
        TextView viewCrop = ListViewItem.findViewById(R.id.textCroptValue);
        TextView viewSoil = ListViewItem.findViewById(R.id.textSoilValue);
        TextView viewMoisture = ListViewItem.findViewById(R.id.textMoistureValue);
        TextView viewTemperature = ListViewItem.findViewById(R.id.textTemperatureValue);
        TextView viewHumidity = ListViewItem.findViewById(R.id.textHumidityValue);


        SaveDataPojo saveDataPojo = dataList.get(position);

        String Name = saveDataPojo.getUser_name_value();
        String Plant = saveDataPojo.getPlant_value();
        String Crop = saveDataPojo.getCrop_value();
        String Soil = saveDataPojo.getSoil_value();
        double mV = saveDataPojo.getMoisture_value();
        double Tempv = saveDataPojo.getTemperature_value();
        double Humidv = saveDataPojo.getHumidity_value();
        //String timeV = saveDataPojo.getTimeCaptureNow();
        //String WdStrV = String.valueOf(WdV);
        //String TempStrv = String.valueOf(Tempv);
        //String HumidStrv = String.valueOf(Humidv);
        //String.format("%.2f", d);
        //yourTextView.setText(String.format("Value of a: %.2f", a));


        viewName.setText(Name);
        viewPlant.setText(Plant);
        viewCrop.setText(Crop);
        viewSoil.setText(Soil);
        viewMoisture.setText(String.format("%.2f", mV));
        viewTemperature.setText(String.format("%.2f", Tempv));
        viewHumidity.setText(String.format("%.2f", Humidv));
        //viewtime.setText(timeV);

        return ListViewItem;

    }
}
