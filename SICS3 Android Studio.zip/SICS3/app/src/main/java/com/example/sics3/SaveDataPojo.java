package com.example.sics3;

public class SaveDataPojo {
    String user_name_value;
    String plant_value, crop_value, soil_value;
    double moisture_value, temperature_value, humidity_value;

    public SaveDataPojo() {
    }

    public SaveDataPojo(String user_name_value, String plant_value, String crop_value, String soil_value, double moisture_value, double temperature_value, double humidity_value) {
        this.user_name_value = user_name_value;
        this.plant_value = plant_value;
        this.crop_value = crop_value;
        this.soil_value = soil_value;
        this.moisture_value = moisture_value;
        this.temperature_value = temperature_value;
        this.humidity_value = humidity_value;
    }

    public String getUser_name_value() {
        return user_name_value;
    }

    public void setUser_name_value(String user_name_value) {
        this.user_name_value = user_name_value;
    }

    public String getPlant_value() {
        return plant_value;
    }

    public void setPlant_value(String name_value) {
        this.plant_value = name_value;
    }

    public String getCrop_value() {
        return crop_value;
    }

    public void setCrop_value(String crop_value) {
        this.crop_value = crop_value;
    }

    public String getSoil_value() {
        return soil_value;
    }

    public void setSoil_value(String soil_value) {
        this.soil_value = soil_value;
    }

    public double getMoisture_value() {
        return moisture_value;
    }

    public void setMoisture_value(double moisture_value) {
        this.moisture_value = moisture_value;
    }

    public double getTemperature_value() {
        return temperature_value;
    }

    public void setTemperature_value(double temperature_value) {
        this.temperature_value = temperature_value;
    }

    public double getHumidity_value() {
        return humidity_value;
    }

    public void setHumidity_value(double humidity_value) {
        this.humidity_value = humidity_value;
    }
}
