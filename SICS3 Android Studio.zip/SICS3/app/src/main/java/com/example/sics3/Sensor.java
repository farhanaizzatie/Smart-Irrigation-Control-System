package com.example.sics3;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Sensor {
    private String moisture;
    private String temperature;
    private String humidity;

    public Sensor(String moisture, String temperature, String humidity) {
        this.moisture = moisture;
        this.temperature = temperature;
        this.humidity = humidity;


    }



    public String getMoisture() {
        return moisture;
    }

    public void setMoisture(String moisture) {
        this.moisture = moisture;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }
}
