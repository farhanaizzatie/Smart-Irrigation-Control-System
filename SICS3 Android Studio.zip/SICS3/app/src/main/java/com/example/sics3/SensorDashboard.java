package com.example.sics3;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SensorDashboard extends AppCompatActivity {


    TextView moist, temp, hum, light, plant_status, current_time, current_date;
    String statusM, statusT, statusH, statusD;
  //  Date  currentDate ;
  //  String timeNow,dayNow,timeCaptureNow;
  //  SimpleDateFormat simpleDateFormat, simpleDateFormat1, simpleDateFormat2, simpleDateFormat3;
    private FirebaseUser mFirebaseuser;
    private String mUserID;
    private FirebaseAuth mAuth;

    FirebaseDatabase myDatabase=FirebaseDatabase.getInstance();
    DatabaseReference ref ;

 /*   SimpleDateFormat sdf=new SimpleDateFormat("hh:mm");
    SimpleDateFormat month=new SimpleDateFormat("MMM");
    SimpleDateFormat todayDate=new SimpleDateFormat("dd");
    SimpleDateFormat ctn = new SimpleDateFormat("hh:mm:ss");
    Date currentTime ;
    String monthNow;*/


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor);

        mAuth = FirebaseAuth.getInstance();
        mFirebaseuser=mAuth.getCurrentUser();
        mUserID=mFirebaseuser.getUid();

      //  currentTime      = Calendar.getInstance().getTime();
      //  monthNow         = month.format(currentTime);



        moist = (TextView) findViewById(R.id.editMoisture);
        temp = (TextView) findViewById(R.id.editTemperature);
        hum = (TextView) findViewById(R.id.editHumidity);
        //light=(TextView) findViewById(R.id.editLight);
        plant_status = (TextView) findViewById(R.id.plantStatus);

     /*   current_time     = findViewById(R.id.Ctime);
        current_date = findViewById(R.id.Cdate);*/

     /*   simpleDateFormat = new SimpleDateFormat(" EEE                                             dd-MMM-yyyy");
        currentDate      = Calendar.getInstance().getTime();
        timeNow          = simpleDateFormat.format(currentTime);
        current_time.setText(timeNow);
        current_date.setText(currentDate);*/

        /* SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z");
         final String currentDateandTime = sdf.format(new Date());
         current_date.setText(currentDateandTime);*/

        ref = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        mFirebaseuser=mAuth.getCurrentUser();
        mUserID=mFirebaseuser.getUid();



        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                //Getting values to store
                String moisture = moist.getText().toString().trim();
                String temperature = temp.getText().toString().trim();
                String humidity = hum.getText().toString().trim();
                //String time = currentDateandTime.getText().toString();
                //String date = (String) current_date.getText();


                //Creating Sensor object
                Sensor sensor = new Sensor(moisture,temperature, humidity);

                //Adding values
                statusM = dataSnapshot.child("moisture").getValue().toString();
                statusT = dataSnapshot.child("temperature").getValue().toString();
                statusH = dataSnapshot.child("humidity").getValue().toString();
                //statusD = dataSnapshot.child("date").getValue().toString();



                sensor.setMoisture(moisture);
                sensor.setTemperature(temperature);
                sensor.setHumidity(humidity);
                //sensor.setDate(currentDateandTime);
               // sensor.setTemperature(date);



                moist.setText(statusM);
                hum.setText(statusH);
                temp.setText(statusT);
               // current_date.setText(currentDateandTime);
                //current_time.setText(timeNow);
                //current_date.setText(currentDate);


                ref.child("Users").child(mUserID).child("sensor").setValue(sensor);
                //ref.child("HistoryTable").child(mUserID).setValue(sensor);

             /*   statusM = dataSnapshot.child("moisture").getValue().toString();
                moist.setText(statusM);
                statusT = dataSnapshot.child("temperature").getValue().toString();
                temp.setText(statusT);
                statusH = dataSnapshot.child("humidity").getValue().toString();
                hum.setText(statusH);
                statusL = dataSnapshot.child("light").getValue().toString();
                light.setText(statusL);*/

                /*****************sensor notification********************/
                int moist_value = Integer.valueOf(dataSnapshot.child("moisture").getValue().toString());
                Float temp_value = Float.valueOf(dataSnapshot.child("temperature").getValue().toString());
                //String light_value = String.valueOf(dataSnapshot.child("light").getValue().toString());

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("PUMP_STATUS");
                DatabaseReference myRef2 = database.getReference("LED_STATUS");

                int WET_SOIL = 25;
                int DRY_SOIL = 15; //average 20
                float HOT_TEMP = 32; //average 30
                int soilThreshold = 35;
              //  String lumen = "Daylight";
              //  String daylight = "Daylight";
              //  String dark = "Dark";

           /*     //----------------------LIGHT-----------------//
                if (moist_value < soilThreshold && light_value.equals(lumen))
                {
                    myRef2.setValue(1);
                }
                else  {
                    myRef2.setValue(0);
                }*/

                //----------------------WATER PUMP-----------------//
                // moisture high,temperature high = pump off
                if (moist_value>=soilThreshold && temp_value >=HOT_TEMP){
                    String pump_stat = "Your plant is in GOOD condition";
                    plant_status.setText("Status: " + pump_stat);
                    myRef.setValue(0);
                } else

                    // moisture high, temperature low = pump off
                    if (moist_value>=soilThreshold && temp_value <=HOT_TEMP){
                        String pump_stat = "Soil condition is MEDIUM";
                        plant_status.setText("Status: " + pump_stat);
                       //myRef.setValue(0);

                    } else
                        //moisture low, temperature high - pump on
                        if (moist_value<soilThreshold && temp_value >=HOT_TEMP){
                            String pump_stat = "Soil condition is DRY";
                            plant_status.setText("Status: " + pump_stat);
                            String messageTitle ="DRY SOIL";
                            String messages ="the soil moisture is LOW, irrigate your plant";
                            notification2(messages, messageTitle);
                            myRef.setValue(1);

                        }else
                            //mositure low, temperature low - pump off
                            if (moist_value<soilThreshold && temp_value <=HOT_TEMP){
                                String pump_stat = "Temperature LOW! No irrigation. Protect your root";
                                plant_status.setText("Status: " + pump_stat);
                               // myRef.setValue(0);

                            } else{
                                String pump_stat = "Something is wrong! Contact your admin";
                                plant_status.setText("Status: " + pump_stat);
                            }
                                /**************sensor status***************************/
                                if (moist_value<=0){
                                    plant_status.setText("Status: Cannot obtain moisture value" );
                                } else if (temp_value<=0){
                                    plant_status.setText("Status: Cannot obtain DHT value ");
                                }  else  if (moist_value<=0 || temp_value <=0 ){
                                    String pump_stat = "Failed to read from sensor!!!";
                                    plant_status.setText("Status: " + pump_stat);
                                    String messageTitle ="ERROR";
                                    String messages =" - please check your sensor";
                                    notification2(messages, messageTitle);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });





    }

    public void notification2(String messages, String messageTitle){
        Intent i = new Intent(this, SensorDashboard.class);
        PendingIntent pi = PendingIntent.getActivity(this,(int)System.currentTimeMillis(),i,0);



        Notification n = new Notification.Builder(this)
                .setContentTitle(messageTitle)
                .setContentText(messages)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentIntent(pi)
                .build();
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        n.flags |= Notification.FLAG_AUTO_CANCEL;
        nm.notify(0,n);

    }





}

