package com.example.sics3;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        sharedPreferences = context.getSharedPreferences("AppKEY",0);
        editor = sharedPreferences.edit();
        editor.apply();
    }

    public void setLogin(boolean login){
        editor.putBoolean("KEY_LOGIN",login);
    }

    public Boolean getLogin(){
        return sharedPreferences.getBoolean("KEY_LOGIN",false);
    }

    public void setUserName(String userName){
        editor.putString("KEY_USERNAME", userName);
        editor.commit();
    }

    public String getUserName(){
        return sharedPreferences.getString("KEY_USERNAME","");
    }
}
