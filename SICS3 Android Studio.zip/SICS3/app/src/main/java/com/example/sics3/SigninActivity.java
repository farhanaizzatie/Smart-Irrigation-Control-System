package com.example.sics3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SigninActivity extends AppCompatActivity {
    private EditText signin_email, signin_password;
    private Button verifyAcc;
    private FirebaseAuth mAuth;
    FirebaseDatabase myDatabase;
    DatabaseReference reff;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin_activity);

        signin_email = findViewById(R.id.email_profile);
        signin_password = findViewById(R.id.password_profile);
        verifyAcc = findViewById(R.id.signin_button);
        mAuth = FirebaseAuth.getInstance();
        myDatabase = FirebaseDatabase.getInstance();

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            Intent intent = new Intent(SigninActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }


        verifyAcc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (validate()) {
                    String email = signin_email.getText().toString().trim();
                    String password = signin_password.getText().toString().trim();


                    mAuth.signInWithEmailAndPassword(email, password)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        reff = FirebaseDatabase.getInstance().getReference().child("Users").child(mAuth.getUid());
                                        reff.addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                String role = dataSnapshot.child("usr_role").getValue().toString();
                                                String pass = dataSnapshot.child("usr_password").getValue().toString();
                                                Toast.makeText(SigninActivity.this, role ,
                                                        Toast.LENGTH_SHORT).show();

                                                if(dataSnapshot.child("usr_role").getValue().toString().contains("farmer"))
                                                {
                                                    startActivity(new Intent(SigninActivity.this, MainActivity.class));
                                                }
                                                else if(dataSnapshot.child("usr_role").getValue().toString().contains("admin"))
                                                {
                                                    startActivity(new Intent(SigninActivity.this, AdminDashboard.class));
                                                }
                                                else
                                                {

                                                    Toast.makeText(SigninActivity.this, "Authentication failed.",
                                                            Toast.LENGTH_SHORT).show();
                                                    Toast.makeText(SigninActivity.this, mAuth.getUid(),
                                                            Toast.LENGTH_SHORT).show();
                                                    Toast.makeText(SigninActivity.this, pass ,
                                                            Toast.LENGTH_SHORT).show();

                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });

                                        /**/
                                    } else {
                                        // If sign in fails, display a message to the user.
                                        //Log.w(TAG, "signInWithEmail:failure", task.getException());
                                        Toast.makeText(SigninActivity.this, "Authentication failed.",
                                                Toast.LENGTH_SHORT).show();
                                        //updateUI(null);
                                    }

                                    // ...
                                }
                            });
                }
            }
        });
    }

    private boolean validate() {
        Boolean result = false;

        String email = ((EditText) findViewById(R.id.email_profile)).getText().toString();
        String password = ((EditText) findViewById(R.id.password_profile)).getText().toString();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(SigninActivity.this, "Authentication failed.",
                    Toast.LENGTH_SHORT).show();

        } else if (email.equals("admin@mail.com") && password.equals("admin123")) {
            Toast.makeText(SigninActivity.this, "Access Granted",
                    Toast.LENGTH_SHORT).show();
            Intent ints = new Intent(this, AdminDashboard.class);
            startActivity(ints);
        } else {
            result = true;
        }

        return result;
    }

    public void link_signup(View v){
        Intent i = new Intent(this, SignupActivity.class);
        startActivity(i);
    }

}