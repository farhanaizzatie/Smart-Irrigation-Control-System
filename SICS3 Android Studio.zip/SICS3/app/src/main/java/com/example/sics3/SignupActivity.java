package com.example.sics3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class SignupActivity extends AppCompatActivity {

    private EditText name, username, email, password, phone, role;
    private Button createAcc;
   // ListView listViewUsers;
    DatabaseReference mDatabase;
    private FirebaseAuth mAuth;
    private FirebaseUser mFirebaseuser;
    private String mUserID;

    //a list to store all the artist from firebase database
   // List<UsrDetail> userList;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_activity);

        name=findViewById(R.id.reg_name);
        username = findViewById(R.id.reg_username);
        email=findViewById(R.id.reg_email);
        password=findViewById(R.id.reg_password);
        phone = findViewById(R.id.reg_phoneNo);
        role = findViewById(R.id.reg_role);
        createAcc=findViewById(R.id.signup_button);

        mAuth = FirebaseAuth.getInstance();
        mDatabase= FirebaseDatabase.getInstance().getReference();

        //list to store artists
       // userList = new ArrayList<>();

        createAcc.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {

                String usr_name = name.getText().toString();
                String usr_username=username.getText().toString();
                String usr_email = email.getText().toString();
                String usr_password= password.getText().toString();
                String usr_hp = phone.getText().toString();
                String usr_role = role.getText().toString();
                String id = mDatabase.push().getKey();


                //final  UsrDetail regAcc = new UsrDetail( id, usr_name,  usr_username,  usr_email,  usr_password,  usr_hp,  usr_role  );



                //creating an Artist Object
             //  final UsrDetail usrDetail = new UsrDetail(id, usr_name,  usr_username,  usr_email,  usr_password,  usr_hp,  usr_role);

                //Saving the Artist
              //  reff.child(id).setValue(usrDetail);

                //Creating plant object
                 final UsrDetail usrDetail = new UsrDetail();

                //Adding values
                usrDetail.setUsr_name(usr_name);
                usrDetail.setUsr_username(usr_username);
                usrDetail.setUsr_email(usr_email);
                usrDetail.setUsr_password(usr_password);
                usrDetail.setUsr_hp(usr_hp);
                usrDetail.setUsr_role(usr_role);
                usrDetail.setUsr_id(id);



                if(!usr_name.isEmpty() && !usr_username.isEmpty() && !usr_email.isEmpty() && !usr_password.isEmpty() && !usr_hp.isEmpty() && !usr_role.isEmpty())
                {
                    mAuth.createUserWithEmailAndPassword(usr_email,usr_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if(task.isSuccessful()){
                                mDatabase.child("Users").child(mAuth.getUid()).setValue(usrDetail);
                                Toast.makeText(
                                        SignupActivity.this, "account created.",
                                        Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(SignupActivity.this, MainActivity.class));
                                name.setText("");
                                username.setText("");
                                email.setText("");
                                password.setText("");
                                phone.setText("");
                                role.setText("");


                            }
                            else{Toast.makeText(
                                    SignupActivity.this, "fail to create account.",
                                    Toast.LENGTH_SHORT).show();}
                        }
                    });

                }
                else{
                    Toast.makeText(
                            SignupActivity.this, "fail to create account.",
                            Toast.LENGTH_SHORT).show();}
            }
        });
    }




}

