package com.example.sics3;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class UserList extends ArrayAdapter<UsrDetail> {

    private Activity context;
    List<UsrDetail> userList;

    public UserList(Activity context, List<UsrDetail> userList){
        super(context,R.layout.layout_user_list, userList);
        this.context = context;
        this.userList = userList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View ListViewItem = inflater.inflate(R.layout.layout_user_list, null, true);

        TextView textViewName = (TextView) ListViewItem.findViewById(R.id.textViewName);
        TextView textViewEmail = (TextView) ListViewItem.findViewById(R.id.textViewEmail);
        TextView textViewPhone = (TextView) ListViewItem.findViewById(R.id.textViewPhone);

        UsrDetail usrDetail =userList.get(position);

        textViewName.setText(usrDetail.getUsr_name());
        textViewEmail.setText(usrDetail.getUsr_email());
        textViewPhone.setText(usrDetail.getUsr_hp());

        return ListViewItem;


    }
}
