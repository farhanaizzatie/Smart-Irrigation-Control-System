package com.example.sics3;
public class UsrDetail {

    private String usr_id;
    private String usr_name;
    private String usr_username;
    private String usr_email;
    private String usr_password;
    private String usr_hp;
    private String usr_role;

    public UsrDetail(String usr_id, String usr_name, String usr_username, String usr_email, String usr_password, String usr_hp,  String usr_role) {
        this.usr_id = usr_id;
        this.usr_name = usr_name;
        this.usr_username = usr_username;
        this.usr_email = usr_email;
        this.usr_password = usr_password;
        this.usr_hp = usr_hp;
        this.usr_role = usr_role;
    }


    public UsrDetail() {
    }

    public String getUsr_id() {
        return usr_id;
    }

    public void setUsr_id(String usr_id) {
        this.usr_id = usr_id;
    }

    public String getUsr_name() {

        return usr_name;
    }

    public void setUsr_name(String usr_name) {

        this.usr_name = usr_name;
    }

    public String getUsr_username() {

        return usr_username;
    }

    public void setUsr_username(String usr_username) {

        this.usr_username = usr_username;
    }


    public String getUsr_email() {

        return usr_email;
    }

    public void setUsr_email(String usr_email) {

        this.usr_email = usr_email;
    }

    public String getUsr_password() {

        return usr_password;
    }

    public void setUsr_password(String usr_password) {

        this.usr_password = usr_password;
    }

    public String getUsr_hp() {

        return usr_hp;
    }

    public void setUsr_hp(String usr_hp) {

        this.usr_hp = usr_hp;
    }


    public String getUsr_role() {
        return usr_role;
    }

    public void setUsr_role(String usr_role) {
        this.usr_role = usr_role;
    }
}
