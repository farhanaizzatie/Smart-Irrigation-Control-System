package com.example.sics3;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewPlant extends AppCompatActivity {

    //DatabaseReference mDatabase;
    private FirebaseAuth mAuth;
    private FirebaseUser mFirebaseuser;
    private String mUserID;

    DatabaseReference databasePlant;


    ListView listViewPlant;

    List<PlantDetails> plantList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_plant_list);

        mAuth = FirebaseAuth.getInstance();
        mFirebaseuser=mAuth.getCurrentUser();
       // mDatabase = FirebaseDatabase.getInstance().getReference();
        mUserID=mFirebaseuser.getUid();

        databasePlant = FirebaseDatabase.getInstance().getReference("Users").child(mUserID).child("plant");

        listViewPlant = (ListView) findViewById(R.id.list_view_plant);

        plantList = new ArrayList<>();

        listViewPlant.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int i, long l) {
                PlantDetails plantDetails = plantList.get(i);
                showUpdateDeleteDialog(plantDetails.getPlant_id(), plantDetails.getPlant_name(), plantDetails.getSoil_type(), plantDetails.getCrop_type());
                return true;
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        databasePlant.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                //clearing the previous artist list
                plantList.clear();

                //iterating through all the nodes
                for (DataSnapshot plantSnapShot : dataSnapshot.getChildren()){

                    //getting artist
                    PlantDetails plantDetails = plantSnapShot.getValue(PlantDetails.class);

                    plantList.add(plantDetails);
                }

                PlantList adapter = new PlantList(ViewPlant.this, plantList);
                listViewPlant.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private boolean updateUser(String plant_id, String plant_name, String soil_type, String crop_type) {
        //getting the specified plant reference
        DatabaseReference dR = FirebaseDatabase.getInstance().getReference("Users").child(mUserID).child("plant").child(plant_id);

        //updating artist
        PlantDetails plantDetails = new PlantDetails(plant_id,  plant_name,  soil_type,  crop_type);
        dR.setValue(plantDetails);
        Toast.makeText(getApplicationContext(), "Plant Updated", Toast.LENGTH_LONG).show();
        return true;
    }

    private void showUpdateDeleteDialog(final String plantId, final String plantName, String plantSoil, String plantCrop) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.update_dialog_plant, null);
        dialogBuilder.setView(dialogView);

        final EditText editTextName = (EditText) dialogView.findViewById(R.id.editTextName);
        final EditText editTextSoil = (EditText) dialogView.findViewById(R.id.editTextSoil);
        final EditText editTextCrop = (EditText) dialogView.findViewById(R.id.editTextCrop);
        final Button buttonUpdate = (Button) dialogView.findViewById(R.id.buttonUpdatePlant);
        final Button buttonDelete = (Button) dialogView.findViewById(R.id.buttonDeletePlant);

        dialogBuilder.setTitle(plantName);
        final AlertDialog b = dialogBuilder.create();
        b.show();


        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String plant_name = editTextName.getText().toString().trim();
                String soil_type = editTextSoil.getText().toString().trim();
                String crop_type = editTextCrop.getText().toString().trim();
                if (!TextUtils.isEmpty(plant_name)) {
                    updateUser(plantId,  plant_name,  soil_type,  crop_type);
                    b.dismiss();
                }
            }
        });


        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                deletePlant(plantId);
                b.dismiss();
            }
        });
    }

    private boolean deletePlant(String plant_id) {
        //getting the specified artist reference
        DatabaseReference dR = FirebaseDatabase.getInstance().getReference("Users").child(mUserID).child("plant").child(plant_id);


        //removing artist
        dR.removeValue();

        //getting the tracks reference for the specified artist
        //DatabaseReference drTracks = FirebaseDatabase.getInstance().getReference("tracks").child(id);

        //removing all tracks
        //drTracks.removeValue();
        Toast.makeText(getApplicationContext(), "Plant Deleted", Toast.LENGTH_LONG).show();

        return true;
    }

}
