package com.example.sics3;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewUser extends AppCompatActivity {

    DatabaseReference databaseUser;

    ListView listViewUser;

    List<UsrDetail> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_user_list);

        databaseUser = FirebaseDatabase.getInstance().getReference("Users");

        listViewUser = (ListView) findViewById(R.id.list_view_plant);

        userList = new ArrayList<>();

        listViewUser.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int i, long l) {
                UsrDetail usrDetail = userList.get(i);
                showUpdateDeleteDialog(usrDetail.getUsr_id(), usrDetail.getUsr_name());
                return true;
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        databaseUser.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                //clearing the previous artist list
                userList.clear();

                //iterating through all the nodes
                for (DataSnapshot userSnapShot : dataSnapshot.getChildren()){

                    //getting artist
                    UsrDetail usrDetail = userSnapShot.getValue(UsrDetail.class);

                   userList.add(usrDetail);
                }

                UserList adapter = new UserList(ViewUser.this, userList);
                listViewUser.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    private boolean updateUser(String id, String usr_name, String usr_username, String usr_email, String usr_password, String usr_hp, String usr_role) {
        //getting the specified artist reference
       DatabaseReference databaseUser = FirebaseDatabase.getInstance().getReference("Users").child(id);


        //updating artist
        UsrDetail usrDetail = new UsrDetail(id, usr_name,  usr_username,  usr_email,  usr_password,  usr_hp,  usr_role);
        databaseUser.setValue(usrDetail);
        Toast.makeText(getApplicationContext(), "User Updated", Toast.LENGTH_LONG).show();
        return true;
    }

    private void showUpdateDeleteDialog(final String userId, final String userName) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.update_dialog, null);
        dialogBuilder.setView(dialogView);

        final EditText editTextName = (EditText) dialogView.findViewById(R.id.editTextName);
        final EditText editTextEmail = (EditText) dialogView.findViewById(R.id.editTextEmail);
        final EditText editTextUserName = (EditText) dialogView.findViewById(R.id.editTextUserName);
        final EditText editTextPhone = (EditText) dialogView.findViewById(R.id.editTextPhone);
        final EditText editTextPassword = (EditText) dialogView.findViewById(R.id.editTextPassword);
        final EditText editTextRole = (EditText) dialogView.findViewById(R.id.editTextRole);
        final Button buttonUpdate = (Button) dialogView.findViewById(R.id.buttonUpdateUser);
        final Button buttonDelete = (Button) dialogView.findViewById(R.id.buttonDeleteUser);

        dialogBuilder.setTitle(userName);
        final AlertDialog b = dialogBuilder.create();
        b.show();


        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextName.getText().toString().trim();
                String email = editTextEmail.getText().toString().trim();
                String username = editTextUserName.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();
                String phone = editTextPhone.getText().toString().trim();
                String role = editTextRole.getText().toString().trim();
                if (!TextUtils.isEmpty(name)) {
                    updateUser(userId, name, email, username, password, phone, role);
                    b.dismiss();
                }
            }
        });


        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                deleteUser(userId);
                b.dismiss();
            }
        });
    }

    private boolean deleteUser(String userId) {
        //getting the specified artist reference
        DatabaseReference dR = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        //removing artist
        dR.removeValue();

        //getting the tracks reference for the specified artist
        //DatabaseReference drTracks = FirebaseDatabase.getInstance().getReference("tracks").child(id);

        //removing all tracks
        //drTracks.removeValue();
        Toast.makeText(getApplicationContext(), "User Deleted", Toast.LENGTH_LONG).show();

        return true;
    }

}
